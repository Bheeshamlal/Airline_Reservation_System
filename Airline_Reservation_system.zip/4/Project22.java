import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


//Javax.swing.JFrame;
class Project22{

    Project22()
    {
        JFrame frame = new JFrame("*************     Fly High with Highers      **************");
        Font f = new Font("Serif",Font.BOLD,30);

        JMenuBar mb = new JMenuBar();
        JMenu m1 = new JMenu("Flights");
        mb.add(m1);
        JMenu m2 = new JMenu("Home");
        m2.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                //JOptionPane.showMessageDialog(frame,"You are successfully loged in:");

                new  Project22();

            }
        });

        mb.add(m2);

        JMenu m3 = new JMenu("Contact");
        mb.add(m3);

        JMenu m4 = new JMenu("Booking");
        mb.add(m4);

        JMenuItem mi1 = new JMenuItem("Seat Reservation");
        mi1.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                //JOptionPane.showMessageDialog(frame,"You are successfully loged in:");

                new Seats();

            }
        });

        m1.add(mi1);

        JMenuItem mi2 = new JMenuItem("Journey Details");
        mi2.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                //JOptionPane.showMessageDialog(frame,"You are successfully loged in:");

                new JourneyDetails();

            }
        });

        m1.add(mi2);

        //JMenuItem mi3 = new JMenuItem("Find Flights");
        //m1.add(mi3);

        //JMenuItem mi4 = new JMenuItem("Class");
        //m1.add(mi4);

        //Header

        JLabel name = new JLabel("Airline Reservation:");
        name.setForeground(Color.RED);
        name.setBounds(40,40,400,50);
        name.setFont(f);
        frame.add(name);

        //Header end

        //Login Panel:

        JPanel login = new JPanel();

        login.setSize(400,350);
        login.setLayout(null);
        login.setBackground(new Color(0,0,0,50));
        login.setBounds(50,110,400,350);

        JTextField formsubmission = new JTextField("Enter Username");

        formsubmission.setBounds(50,50,200,40);
        login.add(formsubmission);

        JPasswordField code = new JPasswordField("Enter Password");
        code.setBounds(50,120,200,40);
        login.add(code);

        JButton button = new JButton("Log in");
        button.setBounds(50,200,80,40);
        login.add(button);

        JButton button2 = new JButton("Sign up");
        button2.setBounds(150,200,80,40);
        login.add(button2);

        button.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                JOptionPane.showMessageDialog(frame,"You are successfully loged in:");

            }
        });

        button2.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                new CreateAccount();
                //JOptionPane.showMessageDialog(frame,"Dear visiotor go to home page and first create your account:");

            }
        });



        //END


        //Background

        ImageIcon BgImage = new ImageIcon("no.jpg");
        Image img = BgImage.getImage();
        Image tempImage = img.getScaledInstance(1500,800,Image.SCALE_SMOOTH);
        BgImage = new ImageIcon(tempImage);
        JLabel background = new JLabel("",BgImage,JLabel.CENTER);
        background.setBounds(0,0,1100,900);
        frame.add(background);
        //background.add(heading);
        background.add(login);


        //End



        frame.setSize(600,600);// for frame
        frame.setLayout(null);
        frame.setVisible(true);//end frame
        frame.setJMenuBar(mb);
        frame.setLocationRelativeTo(null);

    }

    public static void main (String args[]){

        SwingUtilities.invokeLater(new Runnable(){public void run()
        {
            new Project22();
        }
        });
        //or if we do not want to use the swing utilities we can do the below simple thing:
        //new Project22();  but it is a problem
    }

}