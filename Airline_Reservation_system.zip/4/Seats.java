import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class Seats{

     Seats(){

    JFrame frame1 = new JFrame();      
	
	 JPanel login = new JPanel();
	 //login.setPreferredSize(new Dimension(500,200));
	 //login.setSize(10000,10000);
	 login.setLayout(null);
	 //login.setBackground(new Color(0,0,0,50));
	 login.setBounds(50,60,1000,650);
	 frame1.add(login);
	 
	 JButton jbtn = new JButton("Seat-1");
	 jbtn.setBounds(70,10,90,50);
	 login.add(jbtn);
	
	 JButton jbtn2 = new JButton("Seat-2");
	 jbtn2.setBounds(10,80,90,50);
	 login.add(jbtn2);
	
	 JButton jbtn3 = new JButton("Seat-3");
	 jbtn3.setBounds(150,80,90,50);
	 login.add(jbtn3);
	
	 JButton jbtn4 = new JButton("Seat-4");
	 jbtn4.setBounds(10,140,90,50);
	 login.add(jbtn4);
	 
	 
	 
	 JButton jbtn5 = new JButton("Seat-5");
	 jbtn5.setBounds(150,140,90,50);
	 login.add(jbtn5);
	 
	
    JButton jbtn6 = new JButton("Seat-6");
	jbtn6.setBounds(10,200,90,50);
	login.add(jbtn6);
	
	
	 JButton jbtn7 = new JButton("Seat-7");
	 jbtn7.setBounds(150,200,90,50);
	 login.add(jbtn7);
	 
	 
	
	JButton jbtn8 = new JButton("Seat-8");
	jbtn8.setBounds(10,260,90,50);
	login.add(jbtn8);
	
	JButton jbtn9 = new JButton("Seat-9");
	jbtn9.setBounds(150,260,90,50);
	login.add(jbtn9);
	 
	
	JButton jbtn10 = new JButton("Seat-10");
	jbtn10.setBounds(10,320,90,50);
	login.add(jbtn10);
	
	
	JButton jbtn11 = new JButton("Seat-11");
	jbtn11.setBounds(150,320,90,50);
	login.add(jbtn11);
	 
	
	
	
	
	JButton jbtn12 = new JButton("Seat-12");
	jbtn12.setBounds(500,10,90,50);
	login.add(jbtn12);
	
	
	JButton jbtn13 = new JButton("Seat-13");
	jbtn13.setBounds(430,80,90,50);
	login.add(jbtn13);
	
	JButton jbtn14 = new JButton("Seat-14");
	jbtn14.setBounds(570,80,90,50);
	login.add(jbtn14);
	
	
	JButton jbtn15 = new JButton("Seat-15");
	jbtn15.setBounds(430,140,90,50);
	login.add(jbtn15);
	
	JButton jbtn16 = new JButton("Seat-16");
	jbtn16.setBounds(570,140,90,50);
	login.add(jbtn16);
	
	JButton jbtn17 = new JButton("Seat-17");
	jbtn17.setBounds(430,200,90,50);
	login.add(jbtn17);
	
	JButton jbtn18 = new JButton("Seat-18");
	jbtn18.setBounds(570,200,90,50);
	login.add(jbtn18);
	
	
	
	JButton jbtn19 = new JButton("Seat-19");
	jbtn19.setBounds(430,260,90,50);
	login.add(jbtn19);
	
	JButton jbtn20 = new JButton("Seat-20");
	jbtn20.setBounds(570,260,90,50);
	login.add(jbtn20);
	
	JButton jbtn21 = new JButton("Seat-21");
	jbtn21.setBounds(430,320,90,50);
	login.add(jbtn21);
	
	
	JButton jbtn22 = new JButton("Seat-22");
	jbtn22.setBounds(570,320,90,50);
	login.add(jbtn22);
	
	
	
	
	
	
	
	frame1.setSize(500,500);// for frame
    frame1.setLayout(null);
    frame1.setVisible(true);//end frame

	 }

public static void main(String args[]){

   SwingUtilities.invokeLater(new Runnable(){public void run()
	{
		new Seats();
	}
	});
	

   }


}