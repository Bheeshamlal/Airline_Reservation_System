import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


class CreateAccount{

    CreateAccount(){

        JFrame frame1 = new JFrame();

        JPanel login = new JPanel();
        login.setSize(1000,550);
        login.setLayout(null);
        login.setBackground(new Color(0,0,0,50));
        login.setBounds(50,60,800,550);

        JLabel headOfPanel = new JLabel("Create Your Account:");
        headOfPanel.setBounds(110,1,200,100);
        headOfPanel.setForeground(Color.white);
        headOfPanel.setFont(new Font("Serif", Font.BOLD, 18));
        login.add(headOfPanel);

        JLabel jbj = new JLabel("name");
        jbj.setBounds(5,100,40,20);
        jbj.setForeground(Color.white);
        login.add(jbj);

        JTextField jto = new JTextField();
        jto.setBounds(90,100,150,30);
        login.add(jto);

        JLabel jbjsurname = new JLabel("Sur-Name");
        jbjsurname.setBounds(270,100,100,20);
        jbjsurname.setForeground(Color.white);
        login.add(jbjsurname);

        JTextField jtosurname = new JTextField();
        jtosurname.setBounds(360,100,150,30);
        login.add(jtosurname);


        JLabel jlabel = new JLabel("Nationality");
        jlabel.setBounds(510,100,100,30);
        jlabel.setForeground(Color.white);
        login.add(jlabel);

        JTextField jtextfield = new JTextField();
        jtextfield.setBounds(620,100,150,30);
        login.add(jtextfield);

        JLabel jlabelphone = new JLabel("phone");
        jlabelphone.setBounds(5,180,60,30);
        jlabelphone.setForeground(Color.white);
        login.add(jlabelphone);

        JTextField jtextfieldphone = new JTextField();
        jtextfieldphone.setBounds(90,180,150,30);
        login.add(jtextfieldphone);


        JLabel jlabelCNIC = new JLabel("CNIC");
        jlabelCNIC.setBounds(275,180,60,30);
        jlabelCNIC.setForeground(Color.white);
        login.add(jlabelCNIC);

        JTextField jtextfieldCNIC = new JTextField();
        jtextfieldCNIC.setBounds(360,180,150,30);
        login.add(jtextfieldCNIC);

        JLabel jlabelPassport = new JLabel("Passport No");
        jlabelPassport.setBounds(515,180,100,30);
        jlabelPassport.setForeground(Color.white);
        login.add(jlabelPassport);

        JTextField jtextfieldPassport = new JTextField();
        jtextfieldPassport.setBounds(620,180,150,30);
        login.add(jtextfieldPassport);



        JLabel jlabeldateofbirth = new JLabel("Date Of Birth");
        jlabeldateofbirth.setBounds(5,260,150,30);
        jlabeldateofbirth.setForeground(Color.white);
        login.add(jlabeldateofbirth);


        String[] choicesinNumber = { "Date","1", "2","3","4","5","6","7","8","9","10"};
        final JComboBox<String> cbnumber = new JComboBox<String>(choicesinNumber);
        cbnumber.setVisible(true);
        cbnumber.setBounds(90,260,150,30);
        login.add(cbnumber);



        String[] choices = { "Month","January", "February","March","April","May","June","July","August","September","October","November","December"};
        final JComboBox<String> cb = new JComboBox<String>(choices);
        cb.setVisible(true);
        cb.setBounds(360,260,150,30);
        login.add(cb);


        String[] choiceYear = { "Year","1990","1991","1992","1993","1994","1995","1996","1997","1998","1999","2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010"};
        final JComboBox<String> cbyear = new JComboBox<String>(choiceYear);
        cbyear.setVisible(true);
        cbyear.setBounds(620,260,150,30);
        login.add(cbyear);


        JLabel jLabelGender = new JLabel("Gender");
        jLabelGender.setBounds(5,360,150,30);
        jLabelGender.setForeground(Color.white);
        login.add(jLabelGender);

        JRadioButton r1=new JRadioButton("A) Male");
        JRadioButton r2=new JRadioButton("B) Female");
        r1.setBounds(90,360,150,30);
        r2.setBounds(90,420,100,30);
        ButtonGroup bg=new ButtonGroup();
        bg.add(r1);bg.add(r2);
        login.add(r1);login.add(r2);

        JButton jbtno = new JButton("Submit");
        jbtno.setBounds(90,480,90,50);
        login.add(jbtno);
        jbtno.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                JOptionPane.showMessageDialog(frame1,"You Account is successfully created :");

            }
        });


        frame1.setSize(500,500);// for frame
        frame1.setLayout(null);
        frame1.setVisible(true);//end frame

//Background

        ImageIcon BgImage = new ImageIcon("after.jpg");
        Image img = BgImage.getImage();
        Image tempImage = img.getScaledInstance(1500,800,Image.SCALE_SMOOTH);
        BgImage = new ImageIcon(tempImage);
        JLabel background = new JLabel("",BgImage,JLabel.CENTER);
        background.setBounds(0,0,1100,900);
        frame1.add(background);
        background.add(login);
        //End

    }

    public static void main(String args[]){

        SwingUtilities.invokeLater(new Runnable(){public void run()
        {
            new CreateAccount();
        }
        });


    }
}
