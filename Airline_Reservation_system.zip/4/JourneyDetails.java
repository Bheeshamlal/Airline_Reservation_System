import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class JourneyDetails{

    JourneyDetails(){

        JFrame frame1 = new JFrame();



        JPanel login = new JPanel();
        login.setSize(800,450);
        login.setLayout(null);
        login.setBackground(new Color(0,0,0,50));
        login.setBounds(50,60,1000,550);
/*
        JLabel fromCitylabel = new JLabel("From City");
        fromCitylabel.setBounds(10,10,100,100);
        fromCitylabel.setForeground(Color.WHITE);
        login.add(fromCitylabel);

        JTextField fromcityTextfield = new JTextField();
        fromcityTextfield.setBounds(80,30,100,40);
        login.add(fromcityTextfield);


        JLabel toCitylabel = new JLabel("To City");
        toCitylabel.setBounds(220,10,100,100);
        toCitylabel.setForeground(Color.WHITE);
        login.add(toCitylabel);

        JTextField tocityTextfield = new JTextField();
        tocityTextfield.setBounds(280,30,100,40);
        login.add(tocityTextfield);


        JLabel datelabel = new JLabel(" Date");
        datelabel.setBounds(420,10,100,100);
        datelabel.setForeground(Color.WHITE);
        login.add(datelabel);

        JTextField dateTextfield = new JTextField();
        dateTextfield.setBounds(480,30,100,40);
        login.add(dateTextfield);

*/
        String[] choicesinNumber = { "departur from","sukkur", "karachi","Islamabad","Lahore"};
        final JComboBox<String> cbnumber = new JComboBox<String>(choicesinNumber);
        cbnumber.setVisible(true);
        cbnumber.setBounds(10,10,130,50);
        login.add(cbnumber);



        String[] choices = { "landing in","sukkur", "karachi","Islamabad","Lahore"};
        final JComboBox<String> cb = new JComboBox<String>(choices);
        cb.setVisible(true);
        cb.setBounds(220,10,100,50);
        login.add(cb);


        String[] choiceYear = { " Date ","10","11","12","13","14","15"};
        final JComboBox<String> cbyear = new JComboBox<String>(choiceYear);
        cbyear.setVisible(true);
        cbyear.setBounds(420,10,100,50);
        login.add(cbyear);

        JButton jbtno = new JButton("search");
        jbtno.setBounds(540,10,100,50);
        login.add(jbtno);



        frame1.setSize(500,500);// for frame
        frame1.setLayout(null);
        frame1.setVisible(true);//end frame
        frame1.setLocationRelativeTo(null);

        //Background

        ImageIcon BgImage = new ImageIcon("jd.jpg");
        Image img = BgImage.getImage();
        Image tempImage = img.getScaledInstance(1500,800,Image.SCALE_SMOOTH);
        BgImage = new ImageIcon(tempImage);
        JLabel background = new JLabel("",BgImage,JLabel.CENTER);
        background.setBounds(0,0,900,700);
        frame1.add(background);
        background.add(login);
        //End

    }

    public static void main(String args[]){

        SwingUtilities.invokeLater(new Runnable(){public void run()
        {
            new JourneyDetails();
        }
        });


    }
}